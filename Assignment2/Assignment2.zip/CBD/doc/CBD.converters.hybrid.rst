Encapsulating CBD Models in PythonPDEVS
=======================================

.. automodule:: CBD.converters.hybrid
    :members:
    :undoc-members:
    :show-inheritance:

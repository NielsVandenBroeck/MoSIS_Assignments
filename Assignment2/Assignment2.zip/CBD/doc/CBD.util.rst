CBD.util module
===============

.. automodule:: CBD.util
    :members:
    :undoc-members:
    :show-inheritance:

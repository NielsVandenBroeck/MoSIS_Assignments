pyCBD.lib.std module
====================

.. automodule:: pyCBD.lib.std
    :members:
    :undoc-members:
    :show-inheritance:

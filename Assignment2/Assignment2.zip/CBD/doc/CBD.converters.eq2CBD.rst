Generate CBD Models from Equations
==================================

.. automodule:: CBD.converters.eq2CBD
    :members:
    :undoc-members:
    :show-inheritance:

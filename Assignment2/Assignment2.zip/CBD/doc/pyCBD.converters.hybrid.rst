Encapsulating CBD Models in PythonPDEVS
=======================================

.. automodule:: pyCBD.converters.hybrid
    :members:
    :undoc-members:
    :show-inheritance:

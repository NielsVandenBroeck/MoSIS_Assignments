CBD.tracers.tracerVerbose module
================================

.. automodule:: CBD.tracers.tracerVerbose
    :members:
    :undoc-members:
    :show-inheritance:

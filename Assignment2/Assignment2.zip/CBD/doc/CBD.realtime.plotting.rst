CBD.realtime.plotting module
============================

.. automodule:: CBD.realtime.plotting
    :members:
    :undoc-members:
    :show-inheritance:

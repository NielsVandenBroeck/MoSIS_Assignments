CBD.lib.extra module
====================

.. automodule:: CBD.lib.extra
    :members:
    :undoc-members:
    :show-inheritance:

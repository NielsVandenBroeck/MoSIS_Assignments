CBD.scheduling module
=====================

.. automodule:: CBD.scheduling
    :members:
    :undoc-members:
    :show-inheritance:

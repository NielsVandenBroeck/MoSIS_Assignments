pyCBD.lib.extra module
======================

.. automodule:: pyCBD.lib.extra
    :members:
    :undoc-members:
    :show-inheritance:

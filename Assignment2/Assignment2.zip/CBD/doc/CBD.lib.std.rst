CBD.lib.std module
==================

.. automodule:: CBD.lib.std
    :members:
    :undoc-members:
    :show-inheritance:

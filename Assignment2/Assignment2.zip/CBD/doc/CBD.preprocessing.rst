CBD.preprocessing package
=========================

.. automodule:: CBD.preprocessing
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------

.. toctree::

   CBD.preprocessing.butcher
   CBD.preprocessing.rungekutta

